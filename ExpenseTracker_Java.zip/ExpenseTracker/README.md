# Java Expense Tracker

A simple console-based Expense Tracker application developed in Java.

## Features
- Add expenses
- View all expenses
- Calculate total expenses
- Delete expenses
- Category and description support

## Technologies
- Java
- ArrayList
- Scanner
- Object-Oriented Programming

## Run the Project

Open a terminal in the `src` folder:

```bash
javac Expense.java ExpenseTracker.java
java ExpenseTracker
```

## Project Structure

```text
ExpenseTracker/
├── src/
│   ├── Expense.java
│   └── ExpenseTracker.java
├── README.md
└── .gitignore
```

## Future Improvements
- GUI using Java Swing/JavaFX
- MySQL database
- Monthly reports
- Search and filtering
- CSV export
